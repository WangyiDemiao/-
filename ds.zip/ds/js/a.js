<html> 
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>热身</title>
</head>
<body>
  <p id="p1">我是第一段文字</p>
  <p id="p2">我是第二段文字</p>
  
  <script type="text/javascript">
  document.write("hello");	
	document.getElementById("p1").style.color="blue"; 
  </script>
</body>
</html>

